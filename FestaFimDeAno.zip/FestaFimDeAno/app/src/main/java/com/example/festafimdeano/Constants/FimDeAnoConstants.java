package com.example.festafimdeano.Constants;

public class FimDeAnoConstants {
    public static final String PRESENCE_KEY = "presenceKey";
    public static final String CONFIRMATION_YES = "CONFIRMATION_YES";
    public static final String CONFIRMATION_NO = "CONFIRMATION_NO";
}
