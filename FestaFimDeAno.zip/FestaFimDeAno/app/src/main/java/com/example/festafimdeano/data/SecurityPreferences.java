package com.example.festafimdeano.data;

import android.content.Context;
import android.content.SharedPreferences;

public class SecurityPreferences {

    private final SharedPreferences mSharedPreferences;

    public SecurityPreferences(Context mContext){
        this.mSharedPreferences = mContext.getSharedPreferences("FestaFimAno", Context.MODE_PRIVATE);
    }
    public void storeString(String Key, String Value){
        this.mSharedPreferences.edit().putString(Key, Value).apply();
    }
    public String getStoredString(String Key){
        return this.mSharedPreferences.getString(Key,"");
    }
}
